import {
  DataBus
} from './databus.js';
import {
  Seabed
} from './runtime/seabed.js';

import {
  SeaLevel
} from './runtime/sealevel.js';
import {
  Button
} from './runtime/button.js';

import {
  Music
} from './runtime/music.js';
import {
  Score
} from './player/score.js';
import {
  Fish
} from './player/fish.js';

import {
  Obstacle
} from './runtime/obstacle.js';

let miusc = new Music()
let databus = new DataBus();
export class Main {
  constructor() {
    this.canvas = wx.createCanvas();
    this.ctx = this.canvas.getContext("2d");
    databus.canvas = this.canvas;
    databus.ctx = this.ctx;
    //页面初始化
    this.init();
    //注册事件
    this.registerEvent();
  }
  init() {
    this.bg = new Seabed();
    this.score = new Score();
    this.level = new SeaLevel();
    this.btn = new Button();
    this.fish = new Fish();
    this.createObstacle();
    this.startGame();
  }
  //检查是否撞到。。（碰到渔网碰到四周）

  check() {
    //鱼的边框模型，模拟鱼的时间位置
   
    
    const fishBorder = {
      top: this.fish.y,
      bottom: this.fish.y + this.fish.h,
      left: this.fish.x,
      right: this.fish.x + this.fish.w
    };
    //循环遍历所有障碍物
    for (let i = 0; i < databus.obstaclelist.length; i++) {
      //创建障碍物边框模型
      const obstacle = databus.obstaclelist[i];
      const obstacleBorder = {
        top: obstacle.y,
        bottom: obstacle.y + obstacle.h,
        left: obstacle.x,
        right: obstacle.x + obstacle.w
      };

      // if (this.isCheck(fishBorder, obstacleBorder)) {
      //   console.log("抓到鱼了");
      //   databus.gameover = true;
      //   return;

      // }
    }
    //和海平面撞击判断
    if (this.fish.newy + this.fish.h >= databus.canvas.height - this.level.h) {
      console.log('撞击地板了');
      databus.gameover = true; //设置游戏状态，停止游戏
      return;

    }
    // 加分逻辑
    if (this.fish.x > databus.obstaclelist[0].x + databus.obstaclelist[0].img.width && this.score.isScore) {
      wx.vibrateShort({
        success: () => {
          console.log("success");
        },
      })
      this.score.isScore = false;
      this.score.scoreNumber++;
    }
  }
  //验证是否有碰撞
  // isCheck(fish, obstacle) {
  //   let s = false; //为碰撞状态
  //   if (fish.top > obstacle.bottom ||
  //     fish.bottom > obstacle.top ||
  //     fish.right > obstacle.left ||
  //     fish.left > obstacle.right

  //   ) {
  //     s = true;
  //   }
  //   return !s;

  // }


  startGame() {
 
    
    this.check();
    if (!databus.gameover) {
      this.bg.render()
      this.level.render()
      this.score.render()
      this.fish.render()

      // 当障碍物页面只有两个障碍物时，额外在增加两个

      if (databus.obstaclelist[0].x + databus.obstaclelist[0].img.width <= 0 && databus.obstaclelist.length == 4) {
        databus.obstaclelist.shift();
        databus.obstaclelist.shift();
        this.score.isScore=true;
      }
     
      if (databus.obstaclelist[0].x <= (databus.canvas.width - databus.obstaclelist[0].img.width) / 2 && databus.obstaclelist.length == 2) {
        this.createObstacle();
      }
      //渲染障碍物
      databus.obstaclelist.forEach(value => {
        value.render();
      })
      let timer = requestAnimationFrame(() => {
        console.log(1);

        this.startGame()
      });
      databus.timer = timer;
    } else {
      // 游戏结束
      databus.reset();
      this.btn.render()
      cancelAnimationFrame(databus.timer);
      wx.triggerGC();

    }

  }

  //创建障碍物
  createObstacle() {

    //控制上下高度上限
    let minTop = databus.canvas.height / 8; //最高度为屏幕8分
    let maxTop = databus.canvas.height / 2; //最低高度为屏幕的1/2
    // 计算随机数
    let top = minTop + Math.random() * (maxTop - minTop);
    databus.obstaclelist.push(new Obstacle(top, 'images/pi_up.png', 'up'))
    databus.obstaclelist.push(new Obstacle(top, 'images/pi_down.png', 'down'))
  }
  //触摸方法
  registerEvent() {
    wx.onTouchStart(() => {
      if (databus.gameover) {
        console.log('游戏开始');
        databus.gameover = false;
        this.init();

      } else {
        //让鱼跳
        this.fish.y = this.fish.newy;
        //时间清零
        this.fish.time = 0;
      }
    })
  }
}