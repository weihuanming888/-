import {DataBus} from '../databus.js';
let databus=new DataBus();
export class Score{
  constructor(){
    this.scoreNumber=0;
    this.x=0;
    this.y=100;
    this.isScore=true;
  }
  render(){
    databus.ctx.fillText("count:"+this.scoreNumber,this.x,this.y);
    databus.ctx.fillStyle = '#fff';
    databus.ctx.font = '25px STCaiyun';
  }
}